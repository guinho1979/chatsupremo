# 🚂 Deploy do Chat Supremo no Railway

Guia feito a partir da análise do SEU código (`supremo`: Express + `ws` + PostgreSQL).

---

## 🎯 A causa REAL dos seus bugs (importante!)

Examinei seu projeto e a verdade é diferente do que a gente suspeitou no começo:

- Você **não usa o `multer`** pra salvar arquivos (ele está no `package.json`, mas não é usado).
- Suas **fotos** (`photo_url`, `cover_url`) são guardadas em **base64 dentro do PostgreSQL**.
- Suas **cores de nick** (`nick_color`, `msg_color`, gradiente, efeito) também ficam no **PostgreSQL**.

Ou seja: **tudo que sumia estava no banco de dados.** Então o problema nunca foi o
disco efêmero — foi o **banco gratuito do Render**, que (segundo o comentário no seu
próprio `render.yaml.txt`) **expira 30 dias depois de criado**. Quando ele expirou,
levou embora os usuários, as fotos e as cores de uma vez — e tudo "voltou pra versão antiga"
porque o banco resetou pro estado inicial do schema.

👉 **Você estava certo: o problema era o plano grátis** — mais especificamente, o
**banco grátis**. Migrar pra um Postgres persistente (Railway) resolve os três bugs juntos.

---

## ✅ Seu código já está pronto pro Railway (não precisa mexer!)

Confirmei os pontos que costumam quebrar — e os seus já estão certos:

- **Porta** → `server.js` já usa `process.env.PORT`. ✅
- **WebSocket** → o `ws` usa o mesmo `http.Server` do Express. ✅
- **Health check** → você já tem a rota `/health`. ✅
- **SSL do banco** → `db.js` já ativa SSL quando `NODE_ENV=production`. ✅
- **Migração idempotente** → `schema.sql` usa `CREATE TABLE IF NOT EXISTS` e o
  `create-admin` usa `ON CONFLICT`, então rodar a migração várias vezes é seguro. ✅

Por isso, o `railway.json` que te entreguei já roda a migração e cria o admin
automaticamente a cada deploy (igual você fazia no Render). Você não precisa de CLI.

---

## 📋 Passo a passo

### 1. Coloque o `railway.json` na raiz do projeto
Copie o `railway.json` (que te enviei) pra raiz do repositório, junto do `package.json`.
Faça commit e push pro GitHub.

### 2. Crie o projeto no Railway
1. Entre em **railway.com** e faça login com o **GitHub**.
2. **New Project → Deploy from GitHub repo** → escolha o repositório do chat.
   - O primeiro build pode falhar porque o banco ainda não existe. Tudo bem, siga.

### 3. Adicione o banco PostgreSQL
- Dentro do projeto: **New → Database → PostgreSQL**.
- O Railway cria um Postgres **persistente** (não expira como o do Render free).

### 4. Configure as variáveis (no serviço do APP, aba **Variables**)

| Variável         | Valor                          | Obrigatória? |
|------------------|--------------------------------|--------------|
| `DATABASE_URL`   | `${{Postgres.DATABASE_URL}}`   | ✅ Sim        |
| `NODE_ENV`       | `production`                   | ✅ Sim        |
| `JWT_SECRET`     | (string longa e aleatória)¹    | ✅ Sim        |
| `JWT_EXPIRES_IN` | `7d`                           | ✅ Sim        |
| `BOT_SECRET`     | (string aleatória)             | ⬜ Opcional²  |
| `FRONTEND_URL`   | seu domínio (ou deixe sem)     | ⬜ Opcional³  |

> ¹ Gere com: `node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"`
> ² Só precisa se você for usar o endpoint do bot.
> ³ Se você serve os HTMLs pelo mesmo servidor, pode deixar de fora (o CORS cai pra `*`).

⚠️ Em `DATABASE_URL`, cole **literalmente** `${{Postgres.DATABASE_URL}}` — é uma
referência que puxa a URL do banco que o Railway criou. **Não** crie a variável `PORT`.

### 5. Redeploy
Depois de adicionar o banco e as variáveis, o Railway redeploya (ou clique em
**Deploy**). Agora o `startCommand` roda: migração → cria admin → sobe o servidor.

### 6. Gere o domínio público
- **Settings → Networking → Generate Domain** → vira `https://seu-app.up.railway.app`.
- No frontend, o WebSocket deve apontar pra esse host com **`wss://`** (HTTPS):
  ```js
  const ws = new WebSocket("wss://seu-app.up.railway.app/ws");
  ```

---

## 🔐 Depois de subir

- **Troque a senha do admin!** O `create-admin` cria `admin` / `admin123`.
  Entre em `/admin.html`, faça login e altere a senha imediatamente.

## 💸 Sobre o "não sumir mais"
O Railway hoje é **uso pago** (não tem free perpétuo como o Render tinha). O lado bom:
é justamente isso que faz o banco **não expirar**. Mantenha o projeto com saldo/plano
ativo e seus dados ficam de pé — sem aquele reset de 30 dias.

## 🛠️ Se algo der errado
- **Deploy falha no start** → quase sempre é a migração sem `DATABASE_URL`. Confirme
  que o Postgres foi criado e a variável `DATABASE_URL` está com `${{Postgres.DATABASE_URL}}`.
- **Erro de SSL** → confirme `NODE_ENV=production` (seu `db.js` liga o SSL com base nisso).
- **Logs** → aba **Deployments → View Logs** mostra o erro exato.

---

Resumo: seu código já está pronto. O que faltava era um **banco que não expira** —
e é exatamente o que o Railway te dá. 🚀
